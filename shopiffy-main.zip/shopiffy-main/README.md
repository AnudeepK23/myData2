# shopiffy
# FILE IS SECURED! revert back to team for password

shoppify is an online shopping portal for all your daily needs

its a simple interface, fast, and easy one step payment
