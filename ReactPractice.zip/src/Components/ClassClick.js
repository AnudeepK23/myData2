import React, { Component } from 'react'

export class ClassClick extends Component {
    Click(){
        console.log("U are clicked now the button")
    }
    render() {
        return (
            <div>
                <button onClick={this.Click}>
                    Click Me
                </button>
            </div>
        )
    }
}

export default ClassClick
