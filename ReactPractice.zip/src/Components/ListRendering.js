import React from 'react'
import ListRendering2 from './ListRendering2'

// function ListRendering() {

//     //first type
//     // const names= ['BruceLee','Harry','Spiderman']
//     // const nameList = names.map(name => <h2>{name}</h2>)
//     // return (
//     //     <div>{nameList}</div>
//     // )


//     //second type

//     const persons = [
//         {
//             id:1,
//             name:'Spiderman',
//             age:43,
//             skills:'Jumping'
//         },
//         {
//             id:2,
//             name:'Superman',
//             age:36,
//             skills:'Flying'
//         },
//         {
//             id:3,
//             name:'Batman',
//             age:23,
//             skills:'Bating'
//         },
//         {
//             id:4,
//             name:'Antman',
//             age:34,
//             skills:'Biting'
//         }
//     ]

//     //second type
//     // const personList = persons.map(person => (<h2> Iam {person.name} . I am {person.age} old. Iam Good in {person.skills}</h2>))
//     // return <div>{personList}</div>

//     //third type
//     // const personList = persons.map(person => <ListRendering2 person={person} />)
//     // return <div>{personList}</div>


// //using key when key is unique it will show warning in console
// // const personList = persons.map(person => <ListRendering2 key="unique" person={person} />)
// // return <div>{personList}</div>


// //using key when key is used as id or name it will not show warning in console
// // const personList = persons.map(person => <ListRendering2 key={person.id} person={person} />)

// // (OR)
// const personList = persons.map(person => <ListRendering2 key={person.name} person={person} />)
// return <div>{personList}</div>

// }

// export default ListRendering







//INDEX AS KEY ANTI-PATTERN

function ListRendering() {

    
     const names= ['BruceLee','Harry','Spiderman','Harry']
    const nameList = names.map((name,index) => <h2 key={index}> {index} {name}</h2>)
    return (
        <div>{nameList}</div>
    )
    }

export default ListRendering