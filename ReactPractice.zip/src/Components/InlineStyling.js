import React from 'react'

const heading = {
    fontSize: '22px',
    color:'blue',
    textAlign:'Right'


}

const divis={
    backgroundColor:'lightblue'
}
function InlineStyling() {
    return (
        <div style={divis}>
            <h1 style={heading}>Inline Styling means Styling inside js file only.</h1>
        </div>
    )
}

export default InlineStyling
