import React from 'react';

import Greet from "./proptopic";

function Product({name, description, price}){
    return(
        <div>
            <Greet name={name} description={description} />
            <h3>${price}</h3>
           
        </div>
    )
}

// export default Product;



// function Product({name, description, price}){
//     increment( ){
//         this.setstate(
//             {
//                 price:this.state.price
//             }
//         )
//     }
//     return(
//         <div>
//             <Greet name={name} description={description} />
//             <h3>${price} + {this.state.price}</h3>
//             <button onClick={()=>this.increment()} >Increment</button>
//         </div>
//     )
// }

export default Product;


