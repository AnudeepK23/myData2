import React, {Component} from 'react';


//first type

// const Greet = (props) => {
//     console.log(props)
//     return(
//         <div>
//             <h1>This is Parent Component Name used in app.js file {props.name}</h1>
//             {props.children}
//         </div>
//     )
// }
// export default Greet;


//second type

// class Greet extends Component {
//     constructor(props) {
//         super(props);
//         this.state = { 
//             message:'Welcome Obama'
//          }
//     }
//     changeMessage(){
//         this.setState(
//             {
//                 message:'Good Morning President'
//             }
//         )
//     }
//     render() { 
//         return ( 
//             <div>
//                 <h1>
//                     {this.state.message}
//                 </h1>
//                 <button onClick={() => this.changeMessage ()} >
//                     change</button> 
//             </div>
//          );
//     }
// }
 
// export default Greet;


//third type
// function Greet({name,description}){
//     return (
//         <div>
//             <p>{name}</p>
//             <p>
//                 <i>
//                     {description}
//                 </i>
//             </p>
//         </div>
//     )
// }

//export default Greet;

//fourth type
class Greet extends Component {
    render(){
        const {name,description}=this.props
        //syntax of state
        //const {state1, state2}=this.state
        return (
            <h1>
                Your name is {name} and your description is {description}
            </h1>
        )
    }
}
export default Greet;