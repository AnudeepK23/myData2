import React, { Component } from 'react'

class EventBind extends Component {
    constructor(props) {
        super(props)
    
        this.state = {
            message:'Good Person'
             
        }

        // third method only 13 th line extra
         this.clickHandler=this.clickHandler.bind(this)

    // }
    // clickHandler(){
    //     this.setState({
    //         message:'Bad Guy'
    //     })
    //     console.log(this)
    // }
    
    }
    clickHandler = () => {
        this.setState({
            message:'Both are not same '
        })
    }
    render() {
        return (
            <div>
                <h1>{this.state.message}</h1>
                {/* first method is binding in render*/}
                {/* <button onClick={this.clickHandler.bind(this)}>Click the button</button> */}
                  {/* second method using fat arrow function */}
                {/* <button onClick={()=>this.clickHandler()}>Click the button</button> */}
                 {/* third method used in constructor */}
                <button  onClick={this.clickHandler}>Click the button</button>
                

                {/* fourth method used in fat arrow function in clickHandler as class property */}
                {/* <button onClick={this.clickHandler}>Click the button</button> */}
            </div>
        )
    }
}

export default EventBind
