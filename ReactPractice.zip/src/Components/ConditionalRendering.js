import React, { Component } from 'react'

 class ConditionalRendering extends Component {
     constructor(props) {
         super(props)
     
         this.state = {
             isLoggedin:true
            //   isLoggedin:false
         }
     }
     
    render() {

//first type => if/else condition
 
        // if(this.state.isLoggedin){
        //     return <div>Welcome Arundhati</div>
            
        // }
        // else{
        //     return  <div>Welcome Pashupathi </div>
            
        // }

//second type => Element Variables
         
        // let message
        // if(this.state.isLoggedin){
        //     message = <div>Welcome Arundhati</div>
            
        // }
        // else{
        //     message = <div>Welcome Pashupathi </div>
            
        // }
        // return <div>{message}</div>


        //third type => ternary conditional operator

        // return (this.state.isLoggedin ? <div>Welcome Arundhati</div> : <div>Welcome Pashupathi</div> )


        //fourth type => Short Circuit Operator

        return this.state.isLoggedin && <div>Welcome Arundhati</div>


        // return (
        //     <div>
        //         <div>Welcome Arundhati</div>
        //         <div>Welcome Pashupathi</div>

        //     </div>
        // )

    }
}

export default ConditionalRendering
