import React from 'react'

function MethodaspropinChildComponent(props) {
    return (
        <div>
            {/* first method  */}
            {/* <button onClick={props.greetHandler}>Click</button> */}
            {/* second method using fat arrow function with  passing parameter */}
            <button onClick={() => props.greetHandler('child')}>Click</button>
        </div>
    )
}

export default MethodaspropinChildComponent
