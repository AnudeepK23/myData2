import React, { Component } from 'react';

class Counter extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            count:0
         }
        }
        //first type
        //  increment(){
        //      this.setState({
        //          count:this.state.count + 1 

        //      },
        //      () =>{
        //          console.log('Call back value : ', this.state.count)

        //      })
        //  }


        increment(){
            this.setState(prevState => ({
                count:prevState.count + 1 

            }))
             
                console.log('Call back value : ', this.state.count)

            }
        
         incrementTen(){
             this.increment();
             this.increment();
             this.increment();
             this.increment();
             this.increment();
             this.increment();
             this.increment();
             this.increment();
             this.increment();
             this.increment();
         }
    
    render() { 
        return ( 
            <div>
                {/* first type */}
                {/* <h1>Count - {this.state.count}</h1>
                <button onClick={()=> this.increment()}>Increment</button> */}
<hr />
                <h1>Count - {this.state.count}</h1>
                <button onClick={()=> this.incrementTen()}>Increment</button>

            </div>
         );
    }
}
 
export default Counter;