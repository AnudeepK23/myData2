import React from 'react'
import "./MyStyles.css";

// function StyleSheet() {
//     return (
//         <div>
//             <h1 className='primary'>StyleSheets Man</h1>
//         </div>
//     )
// }

// export default StyleSheet

//Using props
function StyleSheet(props) {
    let className=props.primary ? 'primary' : '';
    return (
        <div>
            <h1 className={`${className} font-xl`}>StyleSheets Man</h1>
        </div>
    )
}

export default StyleSheet