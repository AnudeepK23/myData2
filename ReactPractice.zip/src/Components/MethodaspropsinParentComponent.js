import React, { Component } from 'react'
import MethodaspropinChildComponent from './MethodaspropinChildComponent'

 class MethodaspropsinParentComponent extends Component {
     constructor(props) {
         super(props)
     
         this.state = {
              Parentname:'Not Same'
         }
         this.greetParent=this.greetParent.bind(this)
     }

      /* first method  */
    //  greetParent(){
    //      alert(`Hello Akhanda ${this.state.Parentname}`)
    //  }

    /* second method using fat arrow function with  passing parameter */
    
    greetParent(childName){
        alert(`Hello Akhanda ${this.state.Parentname} from ${childName}`)
    }
     
    render() {
        return (
            <div>
                <MethodaspropinChildComponent greetHandler={this.greetParent} />
            </div>
        )
    }
}

export default MethodaspropsinParentComponent
