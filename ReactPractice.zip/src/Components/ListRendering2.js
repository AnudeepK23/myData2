import React from 'react'

function ListRendering2({person}) {
    return (
        <div>
           <h2> 
               Iam {person.name} . I am {person.age} old. Iam Good in {person.skills}
               </h2> 
        </div>
    )
}

export default ListRendering2
