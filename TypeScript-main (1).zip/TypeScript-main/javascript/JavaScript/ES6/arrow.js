
() => // single line code;

sub =() =>{
    //multiple line code
};
var x= (a,b) =>a+b

console.log(x(10,20));

var xyz = (x,y) => {
    console.log(`The result is ${x+y}`)
    return x+y;
}

console.log(xyz(20,20));


// function add(x){
//     var a=x;
//     console.log(a);
// }
// add(xyz());