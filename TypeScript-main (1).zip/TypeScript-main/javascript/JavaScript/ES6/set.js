

class abc{
    constructor()
    {
        setTimeout( ()=>{
            console.log('It will print after 5 seconds');
        
        },5000)
    }
}
var a = new abc();