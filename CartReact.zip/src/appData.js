// const data={
//     productItems:[
//         {

export const {dataProducts,prodInDetails}=
    [
    {
        id:1,
        title:"This is cart1",
        company:'Lion',
        img:"https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.wallpaperflare.com%2Flion-lying-on-brown-grass-field-near-trees-savannah-nature-wallpaper-zpqzg&psig=AOvVaw2LjFx8xNUYSo3ZunZQLsoE&ust=1642155508676000&source=images&cd=vfe&ved=0CAgQjRxqFwoTCIikr5DArvUCFQAAAAAdAAAAABAO",
        price:45,
        info:"An image  is an artifact that depicts visual perception, such as a photograph or other two-dimensional picture, that resembles a subject—usually a physical object—and thus provides a depiction of it",
        incart:false,
        count:1
    },
    {
        id:2,
        title:"This is cart1",
        company:'Lion',
        img:"https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.wallpaperflare.com%2Flion-lying-on-brown-grass-field-near-trees-savannah-nature-wallpaper-zpqzg&psig=AOvVaw2LjFx8xNUYSo3ZunZQLsoE&ust=1642155508676000&source=images&cd=vfe&ved=0CAgQjRxqFwoTCIikr5DArvUCFQAAAAAdAAAAABAO",
        price:90,
        info:"An image  is an artifact that depicts visual perception, such as a photograph or other two-dimensional picture, that resembles a subject—usually a physical object—and thus provides a depiction of it",
        incart:false,
        count:1
    },
    {
        id:3,
        title : "This is cart1",
        company:'Lion',
        img :"https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.wallpaperflare.com%2Flion-lying-on-brown-grass-field-near-trees-savannah-nature-wallpaper-zpqzg&psig=AOvVaw2LjFx8xNUYSo3ZunZQLsoE&ust=1642155508676000&source=images&cd=vfe&ved=0CAgQjRxqFwoTCIikr5DArvUCFQAAAAAdAAAAABAO",
        price:88,
        info:"An image  is an artifact that depicts visual perception, such as a photograph or other two-dimensional picture, that resembles a subject—usually a physical object—and thus provides a depiction of it",
        incart:false,
        count:1
    },
    {
        id:4,
        title:"This is cart1",
        company:'Lion',
        img :"https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.wallpaperflare.com%2Flion-lying-on-brown-grass-field-near-trees-savannah-nature-wallpaper-zpqzg&psig=AOvVaw2LjFx8xNUYSo3ZunZQLsoE&ust=1642155508676000&source=images&cd=vfe&ved=0CAgQjRxqFwoTCIikr5DArvUCFQAAAAAdAAAAABAO",
        price:18,
        info : "An image  is an artifact that depicts visual perception, such as a photograph or other two-dimensional picture, that resembles a subject—usually a physical object—and thus provides a depiction of it",
        incart:false,
        count:1
    }

]

 