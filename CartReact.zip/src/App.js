
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css"
import Nav from './Components/Nav';

function App() {
  return (
    <div className="App">
      <h1>Hello</h1>
     <Nav />
    </div>
  );
}

export default App;
