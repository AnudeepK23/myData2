import React, { Component } from 'react';

class Nav extends Component {
    constructor(props) {
        super(props);
        this.state = {  }
    }
    render() { 
        return (
            <div>
                <br />
                <div >
            <title>Bootstrap Example</title>
            <meta charSet="utf-8" />
            <meta name="viewport" content="width=device-width, initial-scale=1" />
            <link
              rel="stylesheet"
              href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css"
            />
            <nav className="navbar navbar-inverse ">
              <div className="container-fluid">
                <div className="navbar-header">
                  <a className="navbar-brand" href="#">
                    Shopping 
                  </a>
                </div>
                <ul className="nav navbar-nav">
                  <li className="active">
                    <a href="#">Home</a>
                  </li>
                  <li>
                    <a href="#">About</a>
                  </li>
                  <li>
                    <a href="#">Contact</a>
                  </li>
                  <li>
                    <a href="#">Cart</a>
                  </li>
                </ul>
                <ul className="nav navbar-nav navbar-right">
                  <li>
                    <a href="#">
                      <span className="glyphicon glyphicon-user" /> Sign Up
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <span className="glyphicon glyphicon-log-in" /> Login
                    </a>
                  </li>
                </ul>
              </div>
            </nav>
            <div className="container">
              <h3>Right Aligned Navbar</h3>
              <p>
                The .navbar-right class is used to right-align navigation bar buttons.
              </p>
            </div>
            </div>
          </div>
          
          );
    }
}
 
export default Nav;