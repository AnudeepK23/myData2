const data={
    productItems:[
        {
            id:"1",
            name:"Dracaena Marginata Plant",
            price:1500,
            
            image:"./pics/dracaena-marginata-house-plant.jpg"
        },
        {
            id:"2",
            name:"Golden Pothos Plant",
            price:2500,
            image:"./pics/pothos-houseplant.jpg"
        },
        {
            id:"3",
            name:"Parlour Palm Plant",
            price:1000,
            image:"./pics/palm-parlour-plant.jpg"
        },
        {
            id:"4",
            name:"Spider Plant",
            price:4500,
            image:"./pics/spider-plant-on-table.jpg"
        },
        {
            id:"5",
            name:"Snake Plant",
            price:5800,
            image:"./pics/snake-plant-in-pot.jpg"
        },
        {
            id:"6",
            name:"Picture of Pachira Plant (Money Tree)",
            price:2000,
            image:"./pics/pachira-indoor-house-plant300250.jpg"
        },
        {
            id:"7",
            name:"Picture of Lucky Bamboo Plant",
            price:1800,
            image:"./pics/lucky-bamboo-indoor-house-plant300250.jpg"
        },
        {
            id:"8",
            name:"Croton Plant",
            price:6200,
            image:"./pics/croton-plant-in-white-pot.jpg"
        },
        {
            id:"9",
            name:"Ficus Tree",
            price:99000,
            image:"./pics/ficus-benjamina-tree (1).jpg"
        },
    ],
};

export default data;