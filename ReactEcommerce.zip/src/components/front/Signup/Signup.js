import React from 'react'
import "./Signup.css";

const Signup =() => {
    return (
        <div className='signup'>Signup</div>
    )
}
export default Signup;