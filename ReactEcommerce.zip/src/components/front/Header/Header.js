import React from 'react';
import {Link} from "react-router-dom";
import "./Header.css";


const Header = () => {
    return (
        <div>
            
<header className='header'>

    <div>
        <h1>
            <Link to="/" className='logo'>
                Green Life
            </Link>
        </h1>
    </div>
    <div className='header-links'>
        <ul className="nav navbar-nav">
            <li>
                <Link to="/">Home</Link>
            </li>
        
            <li>
                <Link to="/about">About</Link>
            </li>
        
            <li>
                <Link to="/cart" className='cart'>
                    <i class="fas fa-shopping-cart" />
                    </Link>
            </li>
       
            <li>
                <Link to="/contact">Contact</Link>
            </li>
        </ul>
        <ul className="nav navbar-nav navbar-right">
                  <li>
                  <Link to="/signup">
                      <span className="glyphicon glyphicon-user" /> Sign Up
                      </Link>
                  </li>
                  <li>
                  <Link to="/login">
                      <span className="glyphicon glyphicon-log-in" /> Login
                      </Link>
                  </li>
                </ul>

        {/* <ul className="nav navbar-nav navbar-right">
                  <li>
                    
                  <Link to="/signup">
                      <span className="glyphicon glyphicon-user" /> Sign Up
                      </Link>
                    
                  </li>
                  <li>
                  <Link to="/login">
                      <span className="glyphicon glyphicon-log-in" /> Login
                      </Link>
                  </li>
                </ul> */}
        {/* <ul>
            <li>
                <Link to="/login">Login</Link>
            </li>
        </ul> */}
        {/* <ul>
            <li>
                <Link to="/signup">Signup</Link>
            </li>
        </ul> */}

    </div>
    {/* </div> */}
</header>
</div>




      

    )
}
export default Header;