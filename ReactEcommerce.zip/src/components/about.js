import React from 'react';

// import React from 'react'

export default function about() {
    return (
        <div className='about'>
            About Page
        </div>
    )
}
