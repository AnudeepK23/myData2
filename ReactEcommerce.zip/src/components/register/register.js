import "./register.css";

import React from 'react'

 function Register() {

     return (
        
          
                <section className="vh-100" style={{backgroundColor: '#eee'}}>
                  <div className="container h-100">
                    <div className="row d-flex justify-content-center align-items-center h-100">
                      <div className="col-lg-12 col-xl-11">
                        <div className="card text-black" style={{borderRadius: '25px'}}>
                          <div className="card-body p-md-5">
                            <div className="row justify-content-center">
                              <div className="col-md-10 col-lg-6 col-xl-5 order-2 order-lg-1">
                                <p className="text-center h1 fw-bold mb-5 mx-1 mx-md-4 mt-4">Sign up</p>
                                <form className="mx-1 mx-md-4">
                                  <div className="d-flex flex-row align-items-center mb-4">
                                    <i className="fas fa-user fa-lg me-3 fa-fw" />
                                    <label className="form-label" htmlFor="form3Example1c">Full Name</label>
                                    <div className="form-outline flex-fill mb-0">
                                      <input type="text" id="form3Example1c" className="form-control" required="required" />
                                      
                                    </div>
                                  </div>
                                  <div className="d-flex flex-row align-items-center mb-4">
                                    <i className="fas fa-envelope fa-lg me-3 fa-fw" />
                                    <label className="form-label" htmlFor="form3Example3c">Your Email</label>
                                    <div className="form-outline flex-fill mb-0">
                                      <input type="email" id="form3Example3c" className="form-control"  required="required" />
                                      
                                    </div>
                                  </div>
                                  <div className="d-flex flex-row align-items-center mb-4">
                                    <i className="fas fa-lock fa-lg me-3 fa-fw" />
                                    <label className="form-label" htmlFor="form3Example4c">Password</label>
                                    <div className="form-outline flex-fill mb-0">
                                      <input type="password" id="form3Example4c" className="form-control" required="required" />
                                     
                                    </div>
                                  </div>
                                  <div className="d-flex flex-row align-items-center mb-4">
                                    <i className="fas fa-mobile fa-lg me-3 fa-fw" />
                                    <label className="form-label" htmlFor="form3Example4cd">Mobile Number</label>
                                    <div className="form-outline flex-fill mb-0">
                                      <input type="tel" pattern="^\d{10}$" id="form3Example4cd" className="form-control" required="required" />
                                     
                                    </div>
                                  </div>
                                  <div className="d-flex flex-row align-items-center mb-4">
                                    <i className="fas fa-map-marker fa-lg me-3 fa-fw" /> <label className="form-label" htmlFor="form3Example4cd">Select Place</label>
                                    <div className="form-outline flex-fill mb-0">
                                    <div class="mb-4">

<select class="select">
  <option value="1" > Select State</option>
  <option value="2">Karnataka</option>
  <option value="3">Andhra Pradesh</option>
  <option value="4">Tamil Nadu</option>
  <option value="5">Kerala</option>
  <option value="6">Maharashtra</option>
</select>

</div>
                                      {/* <input type="tel" pattern="^\d{10}$" id="form3Example4cd" className="form-control" required="required" /> */}
                                     
                                    </div>
                                  </div>
                                  <div className="form-check d-flex justify-content-center mb-5">
                                    <input className="form-check-input me-2" type="checkbox" defaultValue id="form2Example3c" />
                                    <label className="form-check-label" htmlFor="form2Example3">
                                      I agree all statements in <a href="#!">Terms of service</a>
                                    </label>
                                  </div>
                                  <div className="d-flex justify-content-center mx-4 mb-3 mb-lg-4">
                                    <button type="button" className="btn btn-primary btn-lg">Register</button>
                                  </div>
                                </form>
                              </div>
                              <div className="col-md-10 col-lg-6 col-xl-7 d-flex align-items-center order-1 order-lg-2">
                                <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-registration/draw1.webp" className="img-fluid" alt="Sample image" />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </section>
              
              )
            }
            export default Register;


        /* <div className="container">
            
            <form>
                <h1>Registration Form</h1>
                <div className="ui divider"></div>
                <div className="ui form" required="required">
                    <div className="field">
                        <label>Full Name</label>
                        <input type="text" name="fullname" placeholder="fullname" required="required"/>
                    </div>
                    <div className="field">
                        <label>Email</label>
                        <input type="email" name="email" placeholder="Email" required="required"/>
                    </div>
                    <div className="field">
                        <label>Password</label>
                        <input type="password" name="password" placeholder="Password" required="required"/>
                    </div>
                    <div className="field">
                        <label>Mobile Number</label>
                        <input type="tel" name="phone_number" pattern="^\d{10}$" required="required" placeholder="Mobile number" />
          
                       
                        
                    </div>
                    <div className="field">
                        <label>Enter State</label>
                        <input type="text" name="state" placeholder="State" required="required" />
                    </div>
                    <button className="fluid ui button blue">Register</button>
                </div>
            </form>
            
        </div> */

        
//     )
// }
// export default Register;
