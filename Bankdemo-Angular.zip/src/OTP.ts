export class OTP{
    otp:number = 1012;
}