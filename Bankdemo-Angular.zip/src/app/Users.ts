export class Users{
    firstName:string = '';
    lastName:string = '';
    email:string = '';
    password:string = '';
}