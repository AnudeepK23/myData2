import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    window.addEventListener('DOMContentLoaded', (event) => {
    console.log('DOM fully loaded and parsed');


    //set Timer and load to loginpage 
    
// or
    // 1>firebase google
});
  }

}
